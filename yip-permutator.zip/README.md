# yip-permutator

This addon permutates text +/-15 to scramble it. 
You can see if the text is scrambled when it has this form:

```
Yip! <scrambled text> Yip yip!
```

* To scramble it, mark a text in a text field, do a right-click and choose `Yip Permutator / Yiptate`.

* To descramble it, mark the text including the `Yip!` at the beginning and `Yip yip!` at the end, right-click and choose `Yip Permutator / Unyiptate`.
