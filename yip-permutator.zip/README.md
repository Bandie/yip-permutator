# yip-permutator

This addon permutates text +/-15 to scramble it. 
You can see if the text is scrambled when it has this form:

```
Yip! <scrambled text> Yip yip!
```

* To scramble it, mark a text in a text field, do a right-click and choose `Yip Permutator / Yiptate`.

* To descramble it, mark the text including the `Yip!` at the beginning and `Yip yip!` at the end, right-click and choose `Yip Permutator / Unyiptate`.


## Installation

Since this addon is not signed by Mozilla, you need to install it as developing addon.
The downside is, that you have to install it every time you want to use it, using the ZIP file:

1. Download the [ZIP file](https://github.com/Bandie/yip-permutator/releases/download/1.0/yip-permutator.zip).

2. Open `about:debugging#/runtime/this-firefox`

3. Press "Load Temporary Add-on"

4. Choose the zip file.
